import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter/material.dart';

import '../core/routing/app_router.dart';
import '../models/interface_preferences.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  final router = createAppRouter();
  ref.onDispose(router.dispose);
  return router;
});

enum AppSection { home, game, progress, settings }

extension AppSectionRoute on AppSection {
  String get route => switch (this) {
    AppSection.home => AppRoutes.home,
    AppSection.game => AppRoutes.game,
    AppSection.progress => AppRoutes.progress,
    AppSection.settings => AppRoutes.settings,
  };
}

AppSection? sectionForLocation(String location) {
  for (final section in AppSection.values) {
    if (section.route == location) return section;
  }
  return null;
}

class InterfacePreferencesNotifier extends Notifier<InterfacePreferences> {
  @override
  InterfacePreferences build() => const InterfacePreferences();

  void setThemeMode(ThemeMode value) =>
      state = state.copyWith(themeMode: value);
  void setTextScale(double value) => state = state.copyWith(textScale: value);
  void setFontFamily(String value) => state = state.copyWith(fontFamily: value);
  void setSeedColor(Color value) => state = state.copyWith(seedColor: value);
}

final interfacePreferencesProvider =
    NotifierProvider<InterfacePreferencesNotifier, InterfacePreferences>(
      InterfacePreferencesNotifier.new,
    );

final themeModeProvider = Provider<ThemeMode>(
  (ref) => ref.watch(
    interfacePreferencesProvider.select((preferences) => preferences.themeMode),
  ),
);

class SelectedSectionNotifier extends Notifier<AppSection> {
  @override
  AppSection build() => AppSection.home;

  void select(AppSection section) => state = section;
}

final selectedSectionProvider =
    NotifierProvider<SelectedSectionNotifier, AppSection>(
      SelectedSectionNotifier.new,
    );
