import 'package:flutter/material.dart';

import 'app_navigation_bar.dart';

class ResponsiveLayout extends StatelessWidget {
  const ResponsiveLayout({super.key, required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final isWide = constraints.maxWidth >= 900;
      return Scaffold(
        body: isWide
            ? Row(
                children: [
                  const AppNavigationBar(isWide: true),
                  Expanded(child: child),
                ],
              )
            : child,
        bottomNavigationBar: isWide
            ? null
            : const AppNavigationBar(isWide: false),
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      );
    },
  );
}
