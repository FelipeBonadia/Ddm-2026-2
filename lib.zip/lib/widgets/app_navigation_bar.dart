import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../core/constants/app_constants.dart';
import '../core/theme/app_colors.dart';
import '../features/help/presentation/help_dialog.dart';
import '../providers/app_providers.dart';

class AppNavigationBar extends ConsumerWidget {
  const AppNavigationBar({super.key, required this.isWide});

  final bool isWide;

  static const _items = [
    _NavigationDestination('Início', Icons.grid_view_rounded, AppSection.home),
    _NavigationDestination('Jogo', Icons.bolt_rounded, AppSection.game),
    _NavigationDestination(
      'Progresso',
      Icons.insights_rounded,
      AppSection.progress,
    ),
    _NavigationDestination('Ajuda', Icons.help_outline_rounded, null),
    _NavigationDestination(
      'Configurações',
      Icons.tune_rounded,
      AppSection.settings,
    ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final location = GoRouterState.of(context).uri.path;
    final currentSection =
        sectionForLocation(location) ?? ref.watch(selectedSectionProvider);
    final currentIndex = _items.indexWhere(
      (item) => item.section == currentSection,
    );
    final selectedIndex = currentIndex < 0 ? 0 : currentIndex;
    final compact = MediaQuery.sizeOf(context).height < 520;
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    if (!isWide) {
      return SafeArea(
        top: false,
        child: CurvedNavigationBar(
          index: selectedIndex,
          height: 62,
          color: colorScheme.surface,
          buttonBackgroundColor: colorScheme.primary,
          backgroundColor: theme.scaffoldBackgroundColor,
          animationDuration: const Duration(milliseconds: 260),
          items: [
            for (var index = 0; index < _items.length; index++)
              Tooltip(
                message: _items[index].label,
                child: Icon(
                  _items[index].icon,
                  size: 22,
                  color: index == selectedIndex
                      ? colorScheme.onPrimary
                      : colorScheme.onSurfaceVariant,
                ),
              ),
          ],
          onTap: (index) => _selectDestination(context, ref, _items[index]),
        ),
      );
    }

    return SizedBox(
      width: 248,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: colorScheme.surface,
          border: Border(right: BorderSide(color: theme.dividerColor)),
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.fromLTRB(
              22,
              compact ? 12 : 28,
              16,
              compact ? 12 : 20,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: colorScheme.primary,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(
                        Icons.functions_rounded,
                        color: colorScheme.onPrimary,
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        AppConstants.appLabel,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: compact ? 14 : 42),
                for (var index = 0; index < _items.length; index++)
                  Padding(
                    padding: EdgeInsets.only(bottom: compact ? 3 : 6),
                    child: _RailItem(
                      destination: _items[index],
                      selected: index == selectedIndex,
                      onTap: () =>
                          _selectDestination(context, ref, _items[index]),
                      compact: compact,
                    ),
                  ),
                if (!compact) ...[
                  const Spacer(),
                  const Divider(),
                  const SizedBox(height: 12),
                  const Text(
                    'DESAFIOS, UM PASSO DE CADA VEZ',
                    style: TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _selectDestination(
    BuildContext context,
    WidgetRef ref,
    _NavigationDestination destination,
  ) {
    final section = destination.section;
    if (section == null) {
      showDialog<void>(
        context: context,
        builder: (context) => const HelpDialog(),
      );
      return;
    }
    ref.read(selectedSectionProvider.notifier).select(section);
    context.go(section.route);
  }
}

class _RailItem extends StatelessWidget {
  const _RailItem({
    required this.destination,
    required this.selected,
    required this.onTap,
    required this.compact,
  });

  final _NavigationDestination destination;
  final bool selected;
  final VoidCallback onTap;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final color = selected
        ? colorScheme.onSurface
        : colorScheme.onSurfaceVariant;
    return Semantics(
      button: true,
      selected: selected,
      label: destination.label,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: compact ? 40 : 48,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: selected
                ? colorScheme.surfaceContainerHighest
                : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            children: [
              Icon(
                destination.icon,
                size: 20,
                color: selected ? colorScheme.primary : color,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  destination.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: color,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavigationDestination {
  const _NavigationDestination(this.label, this.icon, this.section);

  final String label;
  final IconData icon;
  final AppSection? section;
}
