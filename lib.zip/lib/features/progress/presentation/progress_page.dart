import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../shared/presentation/feature_frame.dart';

class ProgressPage extends StatelessWidget {
  const ProgressPage({super.key});

  @override
  Widget build(BuildContext context) => AppFeatureFrame(
    title: 'Progresso',
    subtitle: 'Acompanhe seus desafios e resultados.',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const _DemoLabel(),
        const SizedBox(height: 12),
        Wrap(
          spacing: 12,
          runSpacing: 12,
          children: const [
            _StatTile(
              label: 'Desafios resolvidos',
              value: '12',
              icon: Icons.check_circle_outline_rounded,
            ),
            _StatTile(
              label: 'Pontuação',
              value: '840',
              icon: Icons.stars_rounded,
            ),
            _StatTile(
              label: 'Melhor sequência',
              value: '3 dias',
              icon: Icons.local_fire_department_rounded,
            ),
          ],
        ),
        const SizedBox(height: 28),
        Text(
          'Histórico ilustrativo',
          style: Theme.of(context).textTheme.titleLarge
              ?.copyWith(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 12),
        const _HistoryTile(
          expression: '6 × 4',
          result: '24',
          difficulty: 'Médio',
        ),
        const _HistoryTile(
          expression: '8 + 7',
          result: '15',
          difficulty: 'Fácil',
        ),
        const _HistoryTile(
          expression: '(9 − 3) × 2',
          result: '12',
          difficulty: 'Médio',
        ),
      ],
    ),
  );
}

class _DemoLabel extends StatelessWidget {
  const _DemoLabel();

  @override
  Widget build(BuildContext context) => const Row(
    children: [
      Icon(Icons.info_outline_rounded, size: 15, color: AppColors.cyan),
      SizedBox(width: 7),
      Text(
        'DADOS DEMONSTRATIVOS',
        style: TextStyle(
          color: AppColors.cyan,
          fontSize: 10,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.9,
        ),
      ),
    ],
  );
}

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) => SizedBox(
    width: 220,
    child: Container(
      constraints: const BoxConstraints(minHeight: 116),
      padding: const EdgeInsets.all(17),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(17),
        border: Border.all(color: Theme.of(context).dividerColor),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 17, color: AppColors.violetBright),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: Theme.of(context).textTheme.titleLarge
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
        ],
      ),
    ),
  );
}

class _HistoryTile extends StatelessWidget {
  const _HistoryTile({
    required this.expression,
    required this.result,
    required this.difficulty,
  });

  final String expression;
  final String result;
  final String difficulty;

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
    decoration: BoxDecoration(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: Theme.of(context).dividerColor),
    ),
    child: Row(
      children: [
        const Icon(Icons.check_rounded, color: AppColors.success, size: 19),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                expression,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              Text(
                'Demonstração · $difficulty',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 11,
                ),
              ),
            ],
          ),
        ),
        Text(
          '= $result',
          style: const TextStyle(
            color: AppColors.cyan,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}
