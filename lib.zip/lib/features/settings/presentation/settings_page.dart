import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_colors.dart';
import '../../../providers/app_providers.dart';
import '../../shared/presentation/feature_frame.dart';

class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  static const _seedColors = [
    Color(0xFF9B7BFF),
    Color(0xFF37BFCF),
    Color(0xFF42A97B),
  ];
  static const _fontFamilies = ['Space Grotesk', 'DM Sans', 'Lato'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final preferences = ref.watch(interfacePreferencesProvider);
    final controller = ref.read(interfacePreferencesProvider.notifier);

    return AppFeatureFrame(
      title: 'Configurações',
      subtitle: 'Ajuste a aparência para o seu jeito de jogar.',
      child: Column(
        children: [
          _SettingsGroup(
            title: 'APARÊNCIA',
            child: SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              title: const Text('Tema escuro'),
              subtitle: Text(
                preferences.themeMode == ThemeMode.dark
                    ? 'Ativado'
                    : 'Desativado',
                style: const TextStyle(color: AppColors.textSecondary),
              ),
              value: preferences.themeMode == ThemeMode.dark,
              onChanged: (enabled) => controller.setThemeMode(
                enabled ? ThemeMode.dark : ThemeMode.light,
              ),
            ),
          ),
          const SizedBox(height: 14),
          _SettingsGroup(
            title: 'LEITURA',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(child: Text('Tamanho da fonte')),
                    Text(
                      '${(preferences.textScale * 100).round()}%',
                      style: const TextStyle(color: AppColors.textSecondary),
                    ),
                  ],
                ),
                Slider(
                  min: 0.85,
                  max: 1.15,
                  divisions: 6,
                  value: preferences.textScale,
                  label: '${(preferences.textScale * 100).round()}%',
                  onChanged: controller.setTextScale,
                ),
                const SizedBox(height: 6),
                const Text('Família tipográfica'),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: preferences.fontFamily,
                  decoration: const InputDecoration(
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),
                  ),
                  items: [
                    for (final family in _fontFamilies)
                      DropdownMenuItem(value: family, child: Text(family)),
                  ],
                  onChanged: (family) {
                    if (family != null) controller.setFontFamily(family);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          _SettingsGroup(
            title: 'COR PRINCIPAL',
            child: Wrap(
              spacing: 14,
              children: [
                for (final color in _seedColors)
                  Tooltip(
                    message: 'Selecionar cor principal',
                    child: InkWell(
                      onTap: () => controller.setSeedColor(color),
                      customBorder: const CircleBorder(),
                      child: Container(
                        width: 38,
                        height: 38,
                        decoration: BoxDecoration(
                          color: color,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: preferences.seedColor == color
                                ? Theme.of(context).colorScheme.onSurface
                                : Colors.transparent,
                            width: 3,
                          ),
                        ),
                        child: preferences.seedColor == color
                            ? const Icon(
                                Icons.check_rounded,
                                size: 18,
                                color: AppColors.background,
                              )
                            : null,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsGroup extends StatelessWidget {
  const _SettingsGroup({required this.title, required this.child});

  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) => Material(
    color: Theme.of(context).colorScheme.surface,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: BorderSide(color: Theme.of(context).dividerColor),
    ),
    child: Padding(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppColors.cyan,
              fontSize: 10,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.1,
            ),
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    ),
  );
}
