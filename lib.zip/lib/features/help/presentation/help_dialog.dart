import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';

class HelpDialog extends StatelessWidget {
  const HelpDialog({super.key});

  @override
  Widget build(BuildContext context) => AlertDialog(
    icon: const Icon(Icons.lightbulb_outline_rounded, color: AppColors.cyan),
    title: const Text('Como jogar'),
    content: const Text(
      'Use os quatro números do desafio e combine operações matemáticas para '
      'alcançar o resultado indicado. Organize sua expressão antes de conferir.',
      style: TextStyle(height: 1.5),
    ),
    actions: [
      FilledButton(
        onPressed: () => Navigator.of(context).pop(),
        child: const Text('Entendi'),
      ),
    ],
  );
}
